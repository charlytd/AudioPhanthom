<?php
$Nombre =$_POST['Nombre'];
$emai =$_POST['email'];
$Telefono =$_POST['Telefono'];
$Mensaje =$_POST['Mensaje'];

$header ='From: ' . $emai . "\r\n";
$header .="X-Mailer: PHP/" . phpversion() ."\r\n";
$header .="Mime-version: 1.0 \r\n";
$header .="Content-Type: text/plain";

$Mensaje ="Este mensaje fue enviado por: " .$Nombre . "\r\n";
$Mensaje .="Su e-mail es: " . $emai . "\r\n";
$Mensaje .="Su telefono de contacto: " . $Telefono . "\r\n";
$Mensaje .="Enviado el: " . date('d/m/Y', time());

$para = 'charlytavira@hotmail.com';
$asunto ='Asunto del mensaje';


mail($para, $asunto, utf8_decode($Mensaje), $header);

header("Location:index.html");
?>